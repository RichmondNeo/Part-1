﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{

    //Recipe data fields
     public class Recipe
    {
        private string recipeName;
        private List<Ingredient> ingredients;
        private List<string> steps;

        //Constructor
        public Recipe()
        {
            ingredients = new List<Ingredient>();
            steps = new List<string>();
        }

        //Method to input Recipe name & ingredient
        public void EnterDetails()
        {
            Console.WriteLine("Please enter the recipe details:");

            Console.Write("Recipe Name: ");
            recipeName = Console.ReadLine();

            Console.Write("Number of Ingredients: ");
            int numberOfIngredients = int.Parse(Console.ReadLine());

            ingredients.Clear();
            for (int i = 0; i < numberOfIngredients; i++)
            {
                Console.WriteLine($"Enter details for Ingredient {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                string quantity = Console.ReadLine();
                Console.Write("Unit of Measurement: ");
                string unit = Console.ReadLine();

                Ingredient ingredient = new Ingredient(name, quantity, unit);
                ingredients.Add(ingredient);
            }

            Console.Write("Number of Steps: ");
            int numberOfSteps = int.Parse(Console.ReadLine());

            steps.Clear();
            for (int i = 0; i < numberOfSteps; i++)
            {
                Console.Write($"Step {i + 1}: ");
                string step = Console.ReadLine();
                steps.Add(step);
            }

            DisplayRecipe();
        }

        //Method to scale the recipe units
        public void ScaleRecipe()
        {
            Console.WriteLine("Enter the scaling factor (0.5, 2, or 3):");
            double factor;
            while (!double.TryParse(Console.ReadLine(), out factor) || (factor != 0.5 && factor != 2 && factor != 3))
            {
                Console.WriteLine("Invalid input. Please enter 0.5, 2, or 3.");
            }

            foreach (var ingredient in ingredients)
            {
                ingredient.ScaleQuantity(factor);
            }

            //Display method
            DisplayRecipe();
        }

        //Method to reset quantity
        public void ResetQuantities()
        {
            foreach (var ingredient in ingredients)
            {
                ingredient.ResetQuantity();
            }

            //Display method
            DisplayRecipe();
        }

        //Method to clear data
        public void ClearData()
        {
            recipeName = null;
            ingredients.Clear();
            steps.Clear();
            Console.WriteLine("Recipe data cleared. You can now enter a new recipe.");
        }

        //Method to display full recipe.
        private void DisplayRecipe()
        {
            Console.WriteLine("\nHere's the recipe:");

            Console.WriteLine($"Recipe Name: {recipeName}\n");

            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"- {ingredient.Quantity} {ingredient.Unit} {ingredient.Name}");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }
    }
}
