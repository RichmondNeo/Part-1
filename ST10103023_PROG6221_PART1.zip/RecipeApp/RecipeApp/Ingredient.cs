﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp
{
    internal class Ingredient
    {
        //Data fields and variables combined with getter method
        public string Name { get; }
        private string originalQuantity;
        private string currentQuantity;
        public string Quantity => currentQuantity;
        public string Unit { get; }

        //Constructor for ingredient class
        public Ingredient(string name, string quantity, string unit)
        {
            Name = name;
            originalQuantity = quantity;
            currentQuantity = quantity;
            Unit = unit;
        }

        //Scale method for ingredient class
        public void ScaleQuantity(double factor)
        {
            double originalValue = double.Parse(originalQuantity);
            double scaledValue = originalValue * factor;
            currentQuantity = scaledValue.ToString();
        }

        //Method to reset quantity
        public void ResetQuantity()
        {
            currentQuantity = originalQuantity;
        }
    }
}

