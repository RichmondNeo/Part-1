﻿namespace RecipeApp
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            //Introduction to program
            Console.WriteLine("Welcome to the Recipe Creator!");

            //Instatiation of Recipe class
            Recipe recipe = new Recipe();
           
            //Loop for user choice
            while (true)
            {
                Console.WriteLine("\nChoose an option:");
                Console.WriteLine("1. Enter Recipe Details");
                Console.WriteLine("2. Scale Recipe");
                Console.WriteLine("3. Reset Quantities");
                Console.WriteLine("4. Clear Data and Start Over");
                Console.WriteLine("5. Exit");

                //choice variable
                int choice;

                //Loop to select correct choice
                while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 5)
                {
                    Console.WriteLine("Invalid input. Please enter a number between 1 and 5.");
                }

                //switch statement to redirect user choice
                switch (choice)
                {
                    case 1:
                        recipe.EnterDetails();
                        break;
                    case 2:
                        recipe.ScaleRecipe();
                        break;
                    case 3:
                        recipe.ResetQuantities();
                        break;
                    case 4:
                        recipe.ClearData();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                }
            }
        }
    }
}
